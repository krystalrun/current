#ifndef USE_LIBSQLITE3
# include "code/sqlite3-binding.c"
#endif

