#ifndef USE_LIBSQLITE3
#include "code/sqlite3-binding.h"
#else
#include <sqlite3.h>
#endif
