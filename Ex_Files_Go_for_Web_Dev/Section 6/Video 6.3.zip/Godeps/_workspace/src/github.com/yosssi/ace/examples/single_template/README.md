# Single Template

This example shows how to build a web application which uses a single Ace template file.
