# Change the Action Delimiter

This example shows how to change the action delimiter.
