#!/bin/sh
go-bindata -o asset.go views
