# Set a Default Value to the Yield Helper Method

This example shows how to set a default value to the yield helper method.
